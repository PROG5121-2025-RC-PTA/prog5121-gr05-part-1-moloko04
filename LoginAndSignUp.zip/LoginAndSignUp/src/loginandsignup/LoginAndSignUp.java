
package loginandsignup;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginAndSignUp {



    public static void main(String[]  args) {
        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        frame.setSize(350, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.add(panel);
        
        
        CardLayout cardLayout = new CardLayout();
        JPanel cardPanel = new JPanel(cardLayout);

        

        frame.add(cardPanel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
    private JPanel createLoginPanel() {
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(10, 20, 80, 25);
        loginPanel.add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(100, 20, 165, 25);
        loginPanel.add(userText);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 50, 80, 25);
        loginPanel.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField();
        passwordText.setBounds(100, 50, 165, 25);
        loginPanel.add(passwordText);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(10, 80, 80, 25);
        loginPanel.add(loginButton);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(100, 80, 100, 25);
        loginPanel.add(registerButton);

        // Action for Login Button
        loginButton.addActionListener((ActionEvent e) -> {
            String username = userText.getText();
            String password = new String(passwordText.getPassword());
            Component frame = null;
            // Add authentication logic here
            JOptionPane.showMessageDialog(frame, "Login Successful for " + username);
        });
    

        return loginPanel;
    }
        private JPanel createRegistrationPanel() {
        JPanel registrationPanel = new JPanel();
        registrationPanel.setLayout(null);

        JLabel userLabel = new JLabel("Full Name:");
        userLabel.setBounds(10, 20, 80, 25);
        registrationPanel.add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(100, 20, 165, 25);
        registrationPanel.add(userText);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 50, 80, 25);
        registrationPanel.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField();
        passwordText.setBounds(100, 50, 165, 25);
        registrationPanel.add(passwordText)
                ;
        JLabel verifyPasswordLabel = new JLabel("Verify Password:");
        verifyPasswordLabel.setBounds(10, 80, 120, 25);
        registrationPanel.add(verifyPasswordLabel);
        
        JLabel cellphoneNumberLabel = new JLabel("Cellphone Number:");
        cellphoneNumberLabel.setBounds(10, 20, 80, 25);
        registrationPanel.add(cellphoneNumberLabel);

        cellphoneNumberText.setBounds(100, 20, 165, 25);
        PopupMenu cellphoneNumberText = null;
        registrationPanel.add(cellphoneNumberText);

        JPasswordField verifyPasswordText = new JPasswordField();
        verifyPasswordText.setBounds(130, 80, 135, 25);
        registrationPanel.add(verifyPasswordText);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(10, 110, 80, 25);
        registrationPanel.add(registerButton);

        JButton backButton = new JButton("Back to Login");
        backButton.setBounds(100, 110, 150, 25);
        registrationPanel.add(backButton);
        return null;
        
        }
                
   
   

	public boolean  checkUserName(String username){
		if(username.contains("_") && username.length() <= 5){
			return true;
		}
		else{
			return false;
		}
	}
	public boolean  checkPasswordComplexity(String password){
		String capital = ".*[A-Z].*";//Checks capital letters
		String small = ".*[a-z].*";//Checks small letters
		String special = ".*[!@#$%^&*(),.?\":{}|<>].*";//Check special characters
		String digit = ".*\\d.*";//Check digit characters
		if(password.length() >= 8 && password.matches(capital) && password.matches(small) 
		&& password.matches(digit) &&password.matches(special)){
			return true;
		}
		else{
			return false;
		}
	}
	public boolean  checkCellPhoneNumber(String phone){
		String saCode = "+27";
		String firstThreeChars = phone.substring(0, 3); // Gets characters from index 0 to 2 (inclusive)
		int fourthDigit = Character.getNumericValue(phone.charAt(3));//Gets and convert the fourth digit
		if(phone.length() <= 12 && firstThreeChars.equals(saCode) && fourthDigit >= 6 && fourthDigit <= 8){
			return true;
		}
		else{
			return false;
		}
	}
	public String registerUser(String username, String password, String phone){
		boolean  validatePhone = checkCellPhoneNumber(phone);
		boolean  validateUsername = checkUserName(username);
		boolean  validatePassword = checkPasswordComplexity(password);
		if(validatePhone == true && validateUsername == true && validatePassword == true){
			return "User is successfully registered";
		}else{
			return "User registration failed!!!!!";
		}
	}
	public boolean loginUser(String username, String password){
		boolean  validUsername = checkUserName(username);
		boolean  validPassword = checkPasswordComplexity(password);
		if(validUsername == true && validPassword == true){
			return true;
		}else{
			return false;
		}
	}
	public String returnLoginStatus(String username, String password){
		boolean  validUsername = checkUserName(username);
		boolean  validPassword = checkPasswordComplexity(password);
		if(validUsername == true && validPassword == true){
			return "A successful login";
		}else{
			return "A failed login";
		}
	}

    private static class cardLayout {

        public cardLayout() {
        }
    }

    private static class cellphoneNumberText {

        private static void setBounds(int i, int i0, int i1, int i2) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public cellphoneNumberText() {
        }
    }
    }

    
    
    
